//Customised database management system

class Customized_DBMS {
    public static void main(String[] args) {

        DBMS obj = new DBMS();
        obj.InsertIntoTable("Amit", "Pune", 89);
        obj.InsertIntoTable("Pooja", "Mumbai", 95);
        obj.InsertIntoTable("Radha", "Satara", 90);
        obj.InsertIntoTable("Neha", "Pune", 78);

        obj.SelectStarFrom();

        obj.SelectStarFromWhereCity("Pune");

        obj.SelectCount();
        obj.SelectSum();
        obj.SelectAVG();
        obj.Max();
        obj.Min();

        obj.SelectStarFromName("Amit");

        obj.updateCity(1, "Mumbai");
        obj.SelectStarFrom();

        obj.DeleteFrom(4);
        obj.SelectStarFrom();

    }
}

class node {

    private static int Counter = 1;

    public int Rno;
    public String Name;
    public String City;
    public int Marks;

    public node next;

    public node(String B, String C, int D) {
        Rno = Counter;
        Counter++;

        Name = B;
        City = C;
        Marks = D;
        next = null;
    }
}

class DBMS {
    public node first;

    public DBMS() {
        first = null;
        System.out.println("DBMS initialised successfully...");
        System.out.println("Student table gets created successfully");
    }

    public void InsertIntoTable(String Name, String City, int Marks) {

        node newn = new node(Name, City, Marks);
        if (first == null) {
            first = newn;
        }

        else {

            node temp = first;

            while (temp.next != null) {

                temp = temp.next;
            }
            temp.next = newn;
        }

        System.out.println("One record get inserted successfully");
    }

    // Display
    // select *from student

    public void SelectStarFrom() {
        System.out.println("Data from the student table is:");

        node temp = first;

        System.out.println("----------------------------------------------------");

        System.out.println("RNo \tName \tCity \tMarks");

        System.out.println("----------------------------------------------------");

        while (temp != null) {
            System.out.println(temp.Rno + "\t" + temp.Name + "\t" + temp.City + "\t" + temp.Marks);
            temp = temp.next;
        }
        System.out.println("----------------------------------------------------");
    }
    // select *from student where City = '_____'

    public void SelectStarFromWhereCity(String str)

    {
        System.out.println("Data from the student table where city is:" + str);

        node temp = first;

        System.out.println("----------------------------------------------------");

        System.out.println("RNo \tName \tCity \tMarks");

        System.out.println("----------------------------------------------------");

        while (temp != null) {
            if (str.equals(temp.City)) // If name of city match
            {
                System.out.println(temp.Rno + "\t" + temp.Name + "\t" + temp.City + "\t" + temp.Marks);

            }
            temp = temp.next;
        }
        System.out.println("----------------------------------------------------");
    }

    public void SelectCount() {
        node temp = first;
        int iCnt = 0;

        while (temp != null)

        {
            temp = temp.next;
            iCnt++;
        }
        System.out.println("Number of records in the table :" + iCnt);
    }

    public void SelectSum() {
        node temp = first;
        int iSum = 0;

        while (temp != null)

        {

            iSum = iSum + temp.Marks;
            temp = temp.next;
        }

        System.out.println("Summation of marks column is:" + iSum);
    }

    public void SelectAVG() {
        node temp = first;
        int iSum = 0, iCnt = 0;

        while (temp != null) {
            iSum = iSum + temp.Marks;
            temp = temp.next;
            iCnt++;
        }
        System.out.println("Average of marks column is:" + (float) ((float) iSum / (float) iCnt));

    }

    public void Min() {
        node temp = first;
        int iMin = 0;
        if (temp != null) {
            iMin = temp.Marks;
        }
        while (temp != null)

        {
            if (temp.Marks < iMin)

            {
                iMin = temp.Marks;
            }
            temp = temp.next;
        }
        System.out.println("Minimum of marks column is:" + iMin);
    }

    public void Max() {
        node temp = first;
        int iMax = 0;
        if (temp != null) {
            iMax = temp.Marks;
        }
        while (temp != null)

        {
            if (temp.Marks > iMax)

            {
                iMax = temp.Marks;
            }
            temp = temp.next;
        }
        System.out.println("Maximum of marks column is:" + iMax);
    }

    // select *from student where name = '____';

    public void SelectStarFromName(String str)

    {
        node temp = first;
        System.out.println("Information of all the student with the name:" + str);

        while (temp != null) {
            if (str.equals(temp.Name)) {
                System.out.println(temp.Rno + "\t" + temp.Name + "\t" + temp.City + "\t" + temp.Marks);
            }
            temp = temp.next;
        }
    }

    public void updateCity(int no, String str)

    {
        node temp = first;
        while (temp != null) {

            if (temp.Rno == no)

            {
                temp.City = str;
                break;
            }
            temp = temp.next;
        }

        System.out.println("Record gets updated...");
    }

    public void DeleteFrom(int no) {
        node temp = first;

        if (temp == null) {
            return;
        }

        if (temp.Rno == no) {
            first = first.next;
            return;
        }

        while (temp.next != null) {
            if (temp.next.Rno == no) {
                temp.next = temp.next.next;
                break;
            }
            temp = temp.next;
        }
    }

}

/*
 * Supported queries
 * 
 * 1: insert into student values('Amit','Pune',78);
 * 2: select *from student;
 * 3: select Count(Marks) from student;
 * 4. select *from student where City = '_____'
 * 5: select Sum(Marks) from student;
 * 6. select Avg(Marks) from student;
 * 7. select Min(Marks) from student;
 * 8. select Max(Marks) from student;
 * 9. select *from student where Name = '____';
 * 10.update student set City = "____" where Rno = ___;
 * 11.delete from student where Rno = ____;
 */